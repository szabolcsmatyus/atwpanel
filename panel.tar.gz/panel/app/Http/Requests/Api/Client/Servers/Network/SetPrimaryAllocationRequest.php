<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Network;

class SetPrimaryAllocationRequest extends UpdateAllocationRequest
{
    /**
     * @return array
     */
    public function rules(): array
    {
        return [];
    }
}
